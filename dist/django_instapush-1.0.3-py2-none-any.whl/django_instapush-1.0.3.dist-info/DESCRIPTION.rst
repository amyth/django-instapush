Django Instapush can be used to send GCM and APNS notifications to android and ios devices respectively. This package supports both mysql and mongoengine models to store device data


